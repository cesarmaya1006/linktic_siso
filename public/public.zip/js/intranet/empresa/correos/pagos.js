$(document).ready(function() {
  //      var numero = $('.pesos').getElemntByClass;
   // $('.pesos').innerHTML =   numero.toLocaleString();
  //  document.getElementById("pesos").innerHTML = numero.toLocaleString();

} );