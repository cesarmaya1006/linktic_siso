$(document).ready(function() {
    function mayus(e) {
        e.value = e.value.toUpperCase();
    }
});
